def testpalin(X):
    x=str(X)
    n=len(x)
    
    if type(n/2)==int:
        for i in range(n/2):
            if x[i]==x[n-i-1]:
                i+=1
            else:
                return False
        return True
    else:
        for i in range(int(n/2)):
            if x[i]==x[n-i-1]:
                i+=1
            else:
                return False
        return True

def revadd(a,n):
    y=''
    X=a
    for i in range(n):
        x=str(X)
        l=len(x)
        if testpalin(X)==True:
            return True
        else:
            y=x[::-1]
            Y=int(y)
            X+=Y
    return False

assert revadd(349,50)==True

def countLyr(n):
    S=0
    for i in range(10,n+1):
        if revadd(i,50)==False:
            S+=1
        else:
            i+=1
    return S

print(countLyr(10000))
            
            
            

                
        
        
