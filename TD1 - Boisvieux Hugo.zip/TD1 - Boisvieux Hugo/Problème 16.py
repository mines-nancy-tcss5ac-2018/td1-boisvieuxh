def solve(n):
    a=str(2**n)
    S=0
    for i in range(len(a)):
        S+=a[i]
    return S
    
print(solve(1000))
    