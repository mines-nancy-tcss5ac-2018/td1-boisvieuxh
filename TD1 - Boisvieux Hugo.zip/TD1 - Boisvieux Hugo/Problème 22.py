f=open('p022_names.txt', 'r')
# txt=f.read()
# f.close()
# 
# listfichier=txt.split(',')
# trifichier=sorted(listfichier)

def tri(fichier):
    listenoms=[]
    for ligne in fichier:
        listenoms+=ligne.split('","')
    return sorted(listenoms)
    
    
l=tri(f)


def alphabet(lettre):
    liste=['"',"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
    for i in range(len(liste)):
        if lettre==liste[i]:
            return i
    
    
    



def valeurprenom(prenom):
    p=prenom
    val=0
    for i in range(len(p)):
        val+=alphabet(p[i])
    return val
    
assert valeurprenom('COLIN')==53

def score(l):
    n=len(l)
    S=0
    for i in range(n):
        S+=(i+1)*valeurprenom(l[i])
    return S
    
print(score(l))
